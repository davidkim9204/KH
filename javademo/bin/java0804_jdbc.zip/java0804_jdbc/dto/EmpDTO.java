package java0804_jdbc.dto;

import java.util.Date;

//DTO : Data Transfer Object
//VO : Variable Object
public class EmpDTO {
	private int employee_id;
	private String first_name;
	private int salary;
	private Date hire_date;
	private DepartmentsDTO mdto;
	private LocationsDTO ldto;

	public EmpDTO() {

	}

	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Date getHire_date() {
		return hire_date;
	}

	public void setHire_date(Date hire_date) {
		this.hire_date = hire_date;
	}

}// end class
