package java0804_jdbc.dto;

public class LocationsDTO {
	private int location_id;
	private String city;

	public LocationsDTO() {

	}

	public int getLocation_id() {
		return location_id;
	}

	public void setLocation_id(int location_id) {
		this.location_id = location_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
}// end class
